package com.tnsif.daythree.constructor;

public class AccountDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Account acc1  = new Account(1001,"Prianka",5000,1234);
		
		System.out.println(acc1.getBalane());		
	}

}

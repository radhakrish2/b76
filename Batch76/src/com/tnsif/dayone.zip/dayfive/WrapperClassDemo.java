package com.tnsif.dayfive;

public class WrapperClassDemo {

	public static void main(String[] args) {
		
		//boolean 1bit // true or false
		//byte
		//short
		//int 
		//long
		
		//float
		//double
		
		//character

	}

}

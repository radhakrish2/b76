package com.tnsif.dayfive.withinheritance;

public class Test {

		public static void main(String[] args) {
			Employee obj = new Employee();
			obj.getName();
		}
}

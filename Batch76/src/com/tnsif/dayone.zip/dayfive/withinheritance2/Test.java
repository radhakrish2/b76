package com.tnsif.dayfive.withinheritance2;

import com.tnsif.dayfive.withinheritance.Employee;

public class Test {

	public static void main(String[] args) {
		Employee obj = new Employee();
		obj.getName();
	}
}
